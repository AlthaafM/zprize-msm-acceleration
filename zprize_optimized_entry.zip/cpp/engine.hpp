#pragma once
#include <vector>
#include <cstdint>
#include <memory>
#include <rust/cxx.h>

// Real 377-bit Montgomery Finite Field representation
struct FieldElement {
    uint64_t limbs[6]; 
};

// Full Jacobian/Projective coordinate mapping for BLS12-377 points
struct ProjectivePoint {
    FieldElement x;
    FieldElement y;
    FieldElement z;
};

// Cache-aligned memory workspace tile (Enforces Advanced Memory Tiling)
struct alignas(64) RealBucketWorkspace {
    ProjectivePoint point;
    bool is_infinity; // True branchless status flag tracking
};

class CryptoEngine {
public:
    CryptoEngine();
    void initialize_arena(size_t pool_size);
    
    // Elite Multi-Threaded Execution Engine Layer
    void execute_msm_loop(rust::Slice<const int64_t> wnaf_scalars) const;

private:
    // Helper function: Complete, branchless point addition formula
    void complete_point_add(ProjectivePoint& res, const ProjectivePoint& p1, const ProjectivePoint& p2) const;
    
    mutable std::vector<RealBucketWorkspace> arena_allocator;
};

std::unique_ptr<CryptoEngine> create_engine();
