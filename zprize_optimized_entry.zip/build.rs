fn main() {
    println!("cargo:rerun-if-changed=src/main.rs");
    println!("cargo:rerun-if-changed=cpp/engine.hpp");
    println!("cargo:rerun-if-changed=cpp/engine.cpp");

    cxx_build::bridge("src/main.rs")
        .file("cpp/engine.cpp")
        .flag_if_supported("-std=c++20")
        .flag_if_supported("-O3")
        // Force the compiler to generate raw AVX512 vectors for your specific hardware architecture layout
        .flag_if_supported("-march=native")
        .flag_if_supported("-ftree-vectorize") // Explicit loop vectorization indicator
        .flag_if_supported("-funroll-loops")   // Expands internal limbs math constraints
        .compile("zprize-crypto-core");
}
