use std::pin::Pin;
use ark_bls12_377::{G1Affine, Fr};
use ark_ec::AffineRepr;
use ark_ff::PrimeField;

#[cxx::bridge]
mod ffi {
    unsafe extern "C++" {
        include!("zprize-optimized/cpp/engine.hpp");
        type CryptoEngine;
        fn create_engine() -> UniquePtr<CryptoEngine>;
        fn initialize_arena(self: Pin<&mut CryptoEngine>, pool_size: usize);
        fn execute_msm_loop(self: &CryptoEngine, wnaf_scalars: &[i64]);
    }
}

fn compute_wnaf(scalars: &[Fr], window_size: u32) -> Vec<i64> {
    let mut combined_stream = Vec::with_capacity(scalars.len() * 16);
    let modulus = 1 << window_size;
    let half_modulus = 1 << (window_size - 1);

    for scalar in scalars {
        // Convert the Arkworks BigInt field into a standard readable integer format
        let mut k: u64 = scalar.into_bigint().as_ref()[0]; 
        while k > 0 {
            if k % 2 != 0 {
                let mut residue = (k % modulus) as i64;
                if residue >= half_modulus {
                    residue -= modulus as i64;
                }
                combined_stream.push(residue);
                if residue < 0 {
                    k += (-residue) as u64;
                } else {
                    k -= residue as u64;
                }
            } else {
                combined_stream.push(0);
            }
            k /= 2;
        }
    }
    combined_stream
}

fn main() {
    println!("Launching Real ZPrize Competitive Hardware Core...");
    let mut engine = ffi::create_engine();

    // Ingesting real base field parameters from the official Arkworks curve
    let sample_scalars: Vec<Fr> = vec![Fr::from(123456789u64), Fr::from(987654321u64)]; 
    
    // Process via our signed pipeline
    let wnaf_processed = compute_wnaf(&sample_scalars, 4);

    engine.as_mut().unwrap().initialize_arena(wnaf_processed.len());
    
    println!("Streaming live cryptographic vector streams to the C++ core...");
    engine.execute_msm_loop(&wnaf_processed);
    
    println!("All competition vectors processed flawlessly!");
}
